/* ============ 照片墙数据 ============ */
window.GALLERY = [
  { thumb: "photos/optimized/stage-thumb.webp", src: "photos/optimized/stage-full.webp", w: 600, h: 400, cap: "舞台上的少年" },
  { thumb: "photos/optimized/日常-thumb.webp", src: "photos/optimized/日常-full.webp", w: 600, h: 800, cap: "这是日常亚" },
  { thumb: "photos/optimized/海胆头回归-thumb.webp", src: "photos/optimized/海胆头回归-full.webp", w: 600, h: 900, cap: "海胆头真神!!" },
  { thumb: "photos/optimized/治愈笑容-thumb.webp", src: "photos/optimized/治愈笑容-full.webp", w: 600, h: 901, cap: "治愈系笑容" },
  { thumb: "photos/optimized/1-thumb.webp", src: "photos/optimized/1-full.webp", w: 600, h: 959, cap: "清新日常" },
  { thumb: "photos/optimized/搞怪宝-thumb.webp", src: "photos/optimized/搞怪宝-full.webp", w: 600, h: 900, cap: "搞怪亚宝" },
  { thumb: "photos/optimized/红发-thumb.webp", src: "photos/optimized/红发-full.webp", w: 600, h: 900, cap: "红发啊啊啊" },
  { thumb: "photos/optimized/老公-thumb.webp", src: "photos/optimized/老公-full.webp", w: 600, h: 900, cap: "完全老公来的" },
  { thumb: "photos/optimized/卖萌-thumb.webp", src: "photos/optimized/卖萌-full.webp", w: 600, h: 901, cap: "要不要这么萌亚" },
  { thumb: "photos/optimized/西装亚-thumb.webp", src: "photos/optimized/西装亚-full.webp", w: 600, h: 900, cap: "妈呀西装爱穿多穿" },
  { thumb: "photos/optimized/搞怪-thumb.webp", src: "photos/optimized/搞怪-full.webp", w: 600, h: 800, cap: "搞怪日常" },
  { thumb: "photos/optimized/舞台-thumb.webp", src: "photos/optimized/舞台-full.webp", w: 600, h: 401, cap: "闪闪发光沉浸于歌曲的你" },
  { thumb: "photos/optimized/蓝衣-thumb.webp", src: "photos/optimized/蓝衣-full.webp", w: 600, h: 900, cap: "穿着应援色回应我们的你" },
  { thumb: "photos/optimized/毕业-thumb.webp", src: "photos/optimized/毕业-full.webp", w: 600, h: 1571, cap: "学长！毕业快乐" },
  { thumb: "photos/optimized/可爱-thumb.webp", src: "photos/optimized/可爱-full.webp", w: 600, h: 900, cap: "来给生活比个耶" },
  { thumb: "photos/optimized/侧脸-thumb.webp", src: "photos/optimized/侧脸-full.webp", w: 600, h: 900, cap: "侧脸暴击，心动预警" }
];
